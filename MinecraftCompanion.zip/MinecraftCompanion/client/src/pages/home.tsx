import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { websocketService } from "@/lib/websocket";
import ConnectionPanel from "@/components/ConnectionPanel";
import BotConsole from "@/components/BotConsole";
import HelpSection from "@/components/HelpSection";
import Footer from "@/components/Footer";
import { BotState } from "@shared/schema";

export default function Home() {
  const { toast } = useToast();
  const [botState, setBotState] = useState<BotState>({
    connected: false,
  });
  const [logMessages, setLogMessages] = useState<{ text: string; type: string }[]>([
    { text: "System: Bot controller initialized. Ready to connect.", type: "system" },
    { text: "System: Enter a command to control the bot.", type: "info" },
  ]);

  // Initialize websocket connection
  useState(() => {
    // Setup websocket listeners
    websocketService.onMessage((data) => {
      try {
        const message = JSON.parse(data);
        
        if (message.type === "log") {
          addLogMessage(message.text, message.logType || "info");
        } else if (message.type === "botState") {
          setBotState(message.data);
        }
      } catch (err) {
        console.error("Error parsing websocket message:", err);
      }
    });

    websocketService.onOpen(() => {
      addLogMessage("WebSocket connection established", "system");
    });

    websocketService.onClose(() => {
      setBotState({ connected: false });
      addLogMessage("WebSocket connection closed", "error");
    });

    websocketService.onError(() => {
      addLogMessage("WebSocket connection error", "error");
    });

    // Connect to websocket
    websocketService.connect();

    // Cleanup on component unmount
    return () => {
      websocketService.disconnect();
    };
  }, []);

  const addLogMessage = (text: string, type: string) => {
    setLogMessages((prev) => [...prev, { text, type }]);
  };

  return (
    <div className="minecraft-bg bg-[#3A2A1A] font-sans text-gray-200 min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Header */}
        <header className="mb-6 text-center">
          <h1 className="font-['Minecraft'] text-4xl md:text-5xl tracking-wide mb-2 text-[#5E7330] drop-shadow-lg">
            MINECRAFT BOT CONTROLLER
          </h1>
          <p className="text-sm md:text-base opacity-80">
            Control your Minecraft bot with simple commands
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Server Connection Panel */}
          <ConnectionPanel 
            botState={botState} 
            addLogMessage={addLogMessage} 
          />

          {/* Bot Console */}
          <BotConsole 
            botState={botState} 
            logMessages={logMessages} 
            addLogMessage={addLogMessage} 
          />
        </div>

        {/* Help Section */}
        <HelpSection />

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
}
