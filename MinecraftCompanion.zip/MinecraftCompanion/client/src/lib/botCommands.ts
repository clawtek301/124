// List of available commands that the bot can perform
export const commandList = {
  movement: [
    { name: 'move forward', args: '[blocks]', description: 'Move forward by specified blocks' },
    { name: 'move backward', args: '[blocks]', description: 'Move backward by specified blocks' },
    { name: 'turn left', args: '', description: 'Turn left by 90 degrees' },
    { name: 'turn right', args: '', description: 'Turn right by 90 degrees' },
    { name: 'jump', args: '', description: 'Make the bot jump once' },
    { name: 'look', args: '[x] [y] [z]', description: 'Look at the specified coordinates' },
  ],
  actions: [
    { name: 'attack', args: '', description: 'Attack the entity the bot is looking at' },
    { name: 'use', args: '', description: 'Use the item the bot is holding' },
    { name: 'place', args: '[block]', description: 'Place the block the bot is holding' },
    { name: 'equip', args: '[item]', description: 'Equip the specified item' },
    { name: 'drop', args: '[item] [amount]', description: 'Drop the specified item' },
    { name: 'collect', args: '[item]', description: 'Collect the specified item' },
  ],
  system: [
    { name: 'reconnect', args: '', description: 'Reconnect to the server' },
    { name: 'say', args: '[message]', description: 'Send a chat message' },
    { name: 'help', args: '', description: 'Show this help message' },
    { name: 'list', args: '', description: 'List all online players' },
  ],
};

// Parse a user-entered command into components
export function parseCommand(commandStr: string): { command: string; args: string[] } {
  const parts = commandStr.trim().split(' ');
  const command = parts[0].toLowerCase();
  const args = parts.slice(1);
  return { command, args };
}

// Check if a command is valid
export function isValidCommand(command: string): boolean {
  const allCommands = [
    ...commandList.movement.map(c => c.name),
    ...commandList.actions.map(c => c.name),
    ...commandList.system.map(c => c.name),
  ];
  
  return allCommands.some(c => command.startsWith(c));
}

// Generate help text for all commands
export function getHelpText(): string {
  let helpText = 'Available commands:\n';
  
  helpText += '\nMovement:\n';
  commandList.movement.forEach(cmd => {
    helpText += `  ${cmd.name} ${cmd.args} - ${cmd.description}\n`;
  });
  
  helpText += '\nActions:\n';
  commandList.actions.forEach(cmd => {
    helpText += `  ${cmd.name} ${cmd.args} - ${cmd.description}\n`;
  });
  
  helpText += '\nSystem:\n';
  commandList.system.forEach(cmd => {
    helpText += `  ${cmd.name} ${cmd.args} - ${cmd.description}\n`;
  });
  
  return helpText;
}
