class WebSocketService {
  private ws: WebSocket | null = null;
  private messageListeners: Array<(data: string) => void> = [];
  private openListeners: Array<() => void> = [];
  private closeListeners: Array<() => void> = [];
  private errorListeners: Array<() => void> = [];

  public connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      console.log("WebSocket already connected or connecting");
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    this.ws = new WebSocket(wsUrl);

    this.ws.onopen = () => {
      console.log("WebSocket connection established");
      this.openListeners.forEach(listener => listener());
    };

    this.ws.onmessage = (event) => {
      this.messageListeners.forEach(listener => listener(event.data));
    };

    this.ws.onclose = () => {
      console.log("WebSocket connection closed");
      this.closeListeners.forEach(listener => listener());
      
      // Try to reconnect after 5 seconds
      setTimeout(() => this.connect(), 5000);
    };

    this.ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      this.errorListeners.forEach(listener => listener());
    };
  }

  public disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  public send(data: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(data);
    } else {
      console.error("WebSocket not connected");
    }
  }

  public isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }

  public onMessage(listener: (data: string) => void) {
    this.messageListeners.push(listener);
  }

  public onOpen(listener: () => void) {
    this.openListeners.push(listener);
  }

  public onClose(listener: () => void) {
    this.closeListeners.push(listener);
  }

  public onError(listener: () => void) {
    this.errorListeners.push(listener);
  }
}

export const websocketService = new WebSocketService();
