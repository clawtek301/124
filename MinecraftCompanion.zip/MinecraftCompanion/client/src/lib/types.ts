export interface BotPosition {
  x: number;
  y: number;
  z: number;
}

export interface ConnectionDetails {
  serverAddress: string;
  serverPort: string;
  botUsername: string;
  mcVersion: string;
  authType: string;
  email?: string;
  password?: string;
}

export interface CommandMessage {
  type: 'command';
  data: {
    command: string;
  };
}

export interface ConnectMessage {
  type: 'connect';
  data: ConnectionDetails;
}

export interface DisconnectMessage {
  type: 'disconnect';
}

export interface LogMessage {
  type: 'log';
  text: string;
  logType: 'info' | 'error' | 'success' | 'system' | 'command';
}

export interface BotStateMessage {
  type: 'botState';
  data: {
    connected: boolean;
    position?: BotPosition;
    health?: number;
    food?: number;
    inventory?: any[];
    serverInfo?: {
      host: string;
      port: string;
      version: string;
      username: string;
    };
  };
}

export type WebSocketMessage = 
  | CommandMessage 
  | ConnectMessage 
  | DisconnectMessage 
  | LogMessage 
  | BotStateMessage;
