export default function HelpSection() {
  return (
    <div className="console-bg rounded-lg p-4 mt-6">
      <h2 className="font-['Minecraft'] text-xl border-b border-[#593C27] pb-2 mb-4 text-[#5E7330] flex items-center">
        <span className="material-icons text-base mr-1">help_outline</span>
        COMMAND REFERENCE
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-[#3A2A1A] p-3 rounded-md">
          <h3 className="font-['Minecraft'] text-sm mb-2 text-[#5E7330]">MOVEMENT</h3>
          <ul className="text-sm space-y-1">
            <li><span className="text-gray-400">move forward [blocks]</span> - Move forward</li>
            <li><span className="text-gray-400">move backward [blocks]</span> - Move backward</li>
            <li><span className="text-gray-400">turn [left|right]</span> - Turn direction</li>
            <li><span className="text-gray-400">jump</span> - Jump once</li>
          </ul>
        </div>

        <div className="bg-[#3A2A1A] p-3 rounded-md">
          <h3 className="font-['Minecraft'] text-sm mb-2 text-[#5E7330]">ACTIONS</h3>
          <ul className="text-sm space-y-1">
            <li><span className="text-gray-400">attack</span> - Attack entity in front</li>
            <li><span className="text-gray-400">use</span> - Use held item</li>
            <li><span className="text-gray-400">place [block]</span> - Place held block</li>
            <li><span className="text-gray-400">equip [item]</span> - Equip an item</li>
          </ul>
        </div>

        <div className="bg-[#3A2A1A] p-3 rounded-md">
          <h3 className="font-['Minecraft'] text-sm mb-2 text-[#5E7330]">SYSTEM</h3>
          <ul className="text-sm space-y-1">
            <li><span className="text-gray-400">reconnect</span> - Reconnect to server</li>
            <li><span className="text-gray-400">say [message]</span> - Send chat message</li>
            <li><span className="text-gray-400">look [x] [y] [z]</span> - Look at position</li>
            <li><span className="text-gray-400">help</span> - Show command help</li>
          </ul>
        </div>
      </div>

      <div className="mt-4 text-sm bg-[#3A2A1A] p-3 rounded-md">
        <h3 className="font-['Minecraft'] text-sm mb-2 text-[#5E7330]">ABOUT MINEFLAYER</h3>
        <p>This bot controller uses the Mineflayer.js library, a powerful JavaScript library for creating Minecraft bots. The bot connects to any Minecraft server and can be controlled using simple commands or programmed for automated tasks.</p>
        <p className="mt-2">For advanced usage, you can extend this controller with custom scripts and plugins to create sophisticated bot behaviors.</p>
      </div>
    </div>
  );
}
