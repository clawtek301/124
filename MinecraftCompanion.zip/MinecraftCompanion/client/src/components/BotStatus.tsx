import { BotState } from "@shared/schema";

interface BotStatusProps {
  botState: BotState;
}

export default function BotStatus({ botState }: BotStatusProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
      <div className="bg-[#3A2A1A] rounded-md p-3 border border-[#593C27]">
        <div className="text-xs uppercase opacity-70 mb-1">Status</div>
        <div>
          <span className={`inline-block w-3 h-3 rounded-full mr-2 ${botState.connected ? 'bg-[#66BB6A]' : 'bg-[#F44336]'}`}></span>
          <span className="font-medium">{botState.connected ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>

      <div className="bg-[#3A2A1A] rounded-md p-3 border border-[#593C27]">
        <div className="text-xs uppercase opacity-70 mb-1">Position</div>
        <div>
          {botState.position ? (
            <span className="font-mono text-sm">
              X: {Math.round(botState.position.x)} Y: {Math.round(botState.position.y)} Z: {Math.round(botState.position.z)}
            </span>
          ) : (
            <span className="font-mono text-sm">X: 0 Y: 0 Z: 0</span>
          )}
        </div>
      </div>

      <div className="bg-[#3A2A1A] rounded-md p-3 border border-[#593C27]">
        <div className="text-xs uppercase opacity-70 mb-1">Health</div>
        <div className="flex items-center space-x-1">
          <div className="bg-[#F44336] h-4 w-16 rounded-sm relative overflow-hidden">
            <div 
              className="absolute top-0 left-0 bg-red-600 h-full transition-all duration-300"
              style={{ 
                width: botState.health ? `${(botState.health / 20) * 100}%` : '0%' 
              }}
            ></div>
          </div>
          <span className="text-sm">{botState.health || 0}/20</span>
        </div>
      </div>
    </div>
  );
}
