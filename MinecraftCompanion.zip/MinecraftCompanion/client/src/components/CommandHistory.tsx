import { useEffect, useRef } from "react";

interface CommandHistoryProps {
  messages: { text: string; type: string }[];
}

export default function CommandHistory({ messages }: CommandHistoryProps) {
  const historyRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (historyRef.current) {
      historyRef.current.scrollTop = historyRef.current.scrollHeight;
    }
  }, [messages]);

  const getMessageClass = (type: string) => {
    switch (type) {
      case "error":
        return "text-[#F44336]";
      case "success":
        return "text-[#66BB6A]";
      case "command":
        return "text-white";
      case "system":
        return "text-[#FFA726]";
      default:
        return "text-gray-400";
    }
  };

  return (
    <div
      ref={historyRef}
      className="command-history flex-grow h-64 overflow-y-auto bg-[#3A2A1A] border border-[#593C27] rounded-t-md p-3 font-mono text-sm"
    >
      {messages.map((msg, index) => (
        <div key={index} className={`log-message ${getMessageClass(msg.type)}`}>
          {msg.text}
        </div>
      ))}
    </div>
  );
}
