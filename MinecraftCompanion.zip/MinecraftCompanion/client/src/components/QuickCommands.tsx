import { Button } from "@/components/ui/button";

interface QuickCommandsProps {
  onCommandClick: (command: string) => void;
}

export default function QuickCommands({ onCommandClick }: QuickCommandsProps) {
  const quickCommands = [
    { label: "MOVE FORWARD", command: "move forward 5" },
    { label: "MOVE BACKWARD", command: "move backward 5" },
    { label: "TURN LEFT", command: "turn left" },
    { label: "TURN RIGHT", command: "turn right" },
    { label: "JUMP", command: "jump" },
    { label: "ATTACK", command: "attack" },
    { label: "USE ITEM", command: "use" },
    { label: "EQUIP SWORD", command: "equip sword" },
  ];

  return (
    <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
      {quickCommands.map((cmd, index) => (
        <Button
          key={index}
          type="button"
          onClick={() => onCommandClick(cmd.command)}
          className="minecraft-button bg-[#593C27] hover:bg-[#3A2A1A] text-white text-xs font-['Minecraft'] py-1 px-2 rounded-sm transition"
        >
          {cmd.label}
        </Button>
      ))}
    </div>
  );
}
