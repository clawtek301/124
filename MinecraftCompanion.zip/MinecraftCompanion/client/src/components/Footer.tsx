export default function Footer() {
  return (
    <footer className="mt-6 text-center text-sm opacity-70">
      <p>Minecraft Bot Controller using Mineflayer.js</p>
      <p className="text-xs mt-1">Not affiliated with Mojang Studios or Microsoft</p>
    </footer>
  );
}
