import { useRef } from "react";
import BotStatus from "./BotStatus";
import CommandHistory from "./CommandHistory";
import QuickCommands from "./QuickCommands";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { BotState } from "@shared/schema";
import { websocketService } from "@/lib/websocket";

interface BotConsoleProps {
  botState: BotState;
  logMessages: { text: string; type: string }[];
  addLogMessage: (text: string, type: string) => void;
}

export default function BotConsole({ botState, logMessages, addLogMessage }: BotConsoleProps) {
  const commandInputRef = useRef<HTMLInputElement>(null);

  const handleSendCommand = () => {
    if (!commandInputRef.current) return;
    
    const command = commandInputRef.current.value.trim();
    if (!command) return;

    if (!botState.connected) {
      addLogMessage("Error: Bot is not connected to a server", "error");
      return;
    }

    // Add to command history
    addLogMessage(`Command: ${command}`, "command");

    // Send command to server
    websocketService.send(JSON.stringify({
      type: "command",
      data: { command }
    }));

    // Clear input
    commandInputRef.current.value = "";
  };

  const handleQuickCommand = (command: string) => {
    if (!botState.connected) {
      addLogMessage("Error: Bot is not connected to a server", "error");
      return;
    }

    // Add to command history
    addLogMessage(`Command: ${command}`, "command");

    // Send command to server
    websocketService.send(JSON.stringify({
      type: "command",
      data: { command }
    }));
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendCommand();
    }
  };

  return (
    <div className="console-bg rounded-lg p-4 lg:col-span-2 flex flex-col">
      <h2 className="font-['Minecraft'] text-xl border-b border-[#593C27] pb-2 mb-4 text-[#5E7330] flex items-center">
        <span className="material-icons text-base align-middle mr-1">terminal</span>
        BOT CONSOLE
      </h2>

      {/* Bot Status */}
      <BotStatus botState={botState} />

      {/* Command History */}
      <CommandHistory messages={logMessages} />

      {/* Command Input */}
      <div className="flex">
        <Input
          ref={commandInputRef}
          type="text"
          placeholder="Type a command (e.g., move forward 5)"
          className="flex-grow bg-[#3A2A1A] border border-[#593C27] border-t-0 focus:border-[#5E7330] px-3 py-2 rounded-b-md focus:outline-none text-sm"
          onKeyPress={handleKeyPress}
        />
        <Button
          type="button"
          onClick={handleSendCommand}
          className="minecraft-button bg-[#5E7330] hover:bg-[#435321] text-white font-['Minecraft'] py-2 px-4 rounded-br-md transition"
        >
          SEND
        </Button>
      </div>

      {/* Quick Command Buttons */}
      <QuickCommands onCommandClick={handleQuickCommand} />
    </div>
  );
}
