import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { websocketService } from "@/lib/websocket";
import { ConnectionParams, connectionSchema, BotState } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

interface ConnectionPanelProps {
  botState: BotState;
  addLogMessage: (text: string, type: string) => void;
}

export default function ConnectionPanel({ botState, addLogMessage }: ConnectionPanelProps) {
  const { toast } = useToast();
  const [showAuthFields, setShowAuthFields] = useState(false);

  const form = useForm<ConnectionParams>({
    resolver: zodResolver(connectionSchema),
    defaultValues: {
      serverAddress: "",
      serverPort: "25565",
      botUsername: "",
      mcVersion: "1.19.3",
      authType: "offline",
    },
  });

  const handleConnect = (values: ConnectionParams) => {
    if (!websocketService.isConnected()) {
      addLogMessage("WebSocket not connected. Trying to reconnect...", "error");
      websocketService.connect();
      setTimeout(() => handleConnect(values), 1000);
      return;
    }

    addLogMessage(`Connecting to ${values.serverAddress}:${values.serverPort} as ${values.botUsername}...`, "system");
    
    websocketService.send(JSON.stringify({
      type: "connect",
      data: values
    }));
  };

  const handleDisconnect = () => {
    if (!websocketService.isConnected()) {
      addLogMessage("WebSocket not connected. Cannot disconnect bot.", "error");
      return;
    }

    addLogMessage("Disconnecting from server...", "system");
    websocketService.send(JSON.stringify({
      type: "disconnect"
    }));
  };

  return (
    <div className="console-bg rounded-lg p-4 lg:col-span-1">
      <h2 className="font-['Minecraft'] text-xl border-b border-[#593C27] pb-2 mb-4 text-[#5E7330] flex items-center">
        <span className="material-icons text-base align-middle mr-1">dns</span>
        SERVER CONNECTION
      </h2>

      <Form {...form}>
        <form className="space-y-4" onSubmit={form.handleSubmit(handleConnect)}>
          {/* Server Address and Port */}
          <div>
            <Label htmlFor="serverAddress" className="block text-sm font-medium mb-1">
              Server Address
            </Label>
            <div className="flex">
              <FormField
                control={form.control}
                name="serverAddress"
                render={({ field }) => (
                  <FormItem className="flex-grow">
                    <FormControl>
                      <Input
                        id="serverAddress"
                        placeholder="mc.example.com"
                        className="w-full bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-l-md focus:outline-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="serverPort"
                render={({ field }) => (
                  <FormItem className="w-20">
                    <FormControl>
                      <Input
                        id="serverPort"
                        placeholder="25565"
                        className="w-full bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-r-md focus:outline-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          {/* Bot Username */}
          <FormField
            control={form.control}
            name="botUsername"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="block text-sm font-medium mb-1">Bot Username</FormLabel>
                <FormControl>
                  <Input
                    id="botUsername"
                    placeholder="MinecraftBot"
                    className="w-full bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-md focus:outline-none text-sm"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* MC Version and Auth Type */}
          <div className="flex space-x-2">
            <FormField
              control={form.control}
              name="mcVersion"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel className="block text-sm font-medium mb-1">MC Version</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-md focus:outline-none text-sm">
                        <SelectValue placeholder="Select version" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-[#3A2A1A] border border-[#593C27]">
                      <SelectItem value="1.19.3">1.19.3</SelectItem>
                      <SelectItem value="1.18.2">1.18.2</SelectItem>
                      <SelectItem value="1.17.1">1.17.1</SelectItem>
                      <SelectItem value="1.16.5">1.16.5</SelectItem>
                      <SelectItem value="1.12.2">1.12.2</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="authType"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormLabel className="block text-sm font-medium mb-1">Auth Type</FormLabel>
                  <Select 
                    onValueChange={(value) => {
                      field.onChange(value);
                      setShowAuthFields(value === "microsoft" || value === "mojang");
                    }} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-md focus:outline-none text-sm">
                        <SelectValue placeholder="Select auth" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-[#3A2A1A] border border-[#593C27]">
                      <SelectItem value="microsoft">Microsoft</SelectItem>
                      <SelectItem value="mojang">Mojang</SelectItem>
                      <SelectItem value="offline">Offline</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Auth Fields (conditionally rendered) */}
          {showAuthFields && (
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium mb-1">Email</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        id="email"
                        placeholder="email@example.com"
                        className="w-full bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-md focus:outline-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="block text-sm font-medium mb-1">Password</FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        id="password"
                        placeholder="••••••••"
                        className="w-full bg-[#3A2A1A] border border-[#593C27] focus:border-[#5E7330] px-3 py-2 rounded-md focus:outline-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}

          {/* Connect/Disconnect Buttons */}
          {!botState.connected ? (
            <button
              type="submit"
              className="minecraft-button w-full bg-[#5E7330] hover:bg-[#435321] text-white font-['Minecraft'] py-2 px-4 rounded-sm transition"
            >
              CONNECT
            </button>
          ) : (
            <button
              type="button"
              onClick={handleDisconnect}
              className="minecraft-button w-full bg-[#7F7F7F] text-white font-['Minecraft'] py-2 px-4 rounded-sm transition"
            >
              DISCONNECT
            </button>
          )}
        </form>
      </Form>
    </div>
  );
}
