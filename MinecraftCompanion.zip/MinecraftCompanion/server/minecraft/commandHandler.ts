import { getBot } from './bot';
import { Vec3 } from 'vec3';

// Execute a command string
export async function executeCommand(commandStr: string): Promise<string> {
  const bot = getBot();
  if (!bot) {
    throw new Error('Bot is not connected');
  }

  // Parse the command
  const parts = commandStr.trim().split(' ');
  const command = parts[0].toLowerCase();
  const args = parts.slice(1);

  try {
    // Movement commands
    if (commandStr.startsWith('move forward')) {
      const blocks = parseInt(args[1]) || 1;
      await moveForward(blocks);
      return `Moving forward ${blocks} blocks`;
    } 
    else if (commandStr.startsWith('move backward')) {
      const blocks = parseInt(args[1]) || 1;
      await moveBackward(blocks);
      return `Moving backward ${blocks} blocks`;
    }
    else if (commandStr === 'turn left') {
      await turnLeft();
      return 'Turning left';
    }
    else if (commandStr === 'turn right') {
      await turnRight();
      return 'Turning right';
    }
    else if (commandStr === 'jump') {
      await jump();
      return 'Jumping';
    }
    // Action commands
    else if (commandStr === 'attack') {
      await attack();
      return 'Attacking target';
    }
    else if (commandStr === 'use') {
      await use();
      return 'Using held item';
    }
    else if (commandStr.startsWith('place')) {
      const blockName = args[0] || '';
      await placeBlock(blockName);
      return `Placing ${blockName || 'block'}`;
    }
    else if (commandStr.startsWith('equip')) {
      const itemName = args[0] || '';
      await equipItem(itemName);
      return `Equipping ${itemName}`;
    }
    // System commands
    else if (commandStr.startsWith('say')) {
      const message = parts.slice(1).join(' ');
      await sayMessage(message);
      return `Said: ${message}`;
    }
    else if (commandStr === 'help') {
      return getHelpText();
    }
    else if (commandStr.startsWith('look')) {
      if (args.length >= 3) {
        const x = parseFloat(args[0]);
        const y = parseFloat(args[1]);
        const z = parseFloat(args[2]);
        await lookAt(x, y, z);
        return `Looking at ${x}, ${y}, ${z}`;
      } else {
        throw new Error('Look command requires x, y, z coordinates');
      }
    }
    else if (commandStr === 'list') {
      return listPlayers();
    }
    // Command not recognized
    else {
      throw new Error(`Unknown command: ${commandStr}`);
    }
  } catch (error) {
    throw new Error(`Command error: ${(error as Error).message}`);
  }
}

// Movement implementations
async function moveForward(blocks: number): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  // Get the direction the bot is facing and create a movement vector
  const yaw = bot.entity.yaw;
  const x = -Math.sin(yaw) * blocks;
  const z = -Math.cos(yaw) * blocks;
  
  // Create target position
  const targetPos = bot.entity.position.offset(x, 0, z);
  
  try {
    await bot.pathfinder.goto(targetPos);
  } catch (error) {
    // If pathfinding fails, try to move directly
    await bot.setControlState('forward', true);
    await new Promise(resolve => setTimeout(resolve, blocks * 250));
    await bot.setControlState('forward', false);
  }
}

async function moveBackward(blocks: number): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  // Get the direction the bot is facing and create a movement vector (opposite)
  const yaw = bot.entity.yaw;
  const x = Math.sin(yaw) * blocks;
  const z = Math.cos(yaw) * blocks;
  
  // Create target position
  const targetPos = bot.entity.position.offset(x, 0, z);
  
  try {
    await bot.pathfinder.goto(targetPos);
  } catch (error) {
    // If pathfinding fails, try to move directly
    await bot.setControlState('back', true);
    await new Promise(resolve => setTimeout(resolve, blocks * 250));
    await bot.setControlState('back', false);
  }
}

async function turnLeft(): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  // Turn left by adding 90 degrees (PI/2 radians) to the current yaw
  const newYaw = bot.entity.yaw + Math.PI / 2;
  await bot.look(newYaw, bot.entity.pitch);
}

async function turnRight(): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  // Turn right by subtracting 90 degrees (PI/2 radians) from the current yaw
  const newYaw = bot.entity.yaw - Math.PI / 2;
  await bot.look(newYaw, bot.entity.pitch);
}

async function jump(): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  await bot.setControlState('jump', true);
  await new Promise(resolve => setTimeout(resolve, 250));
  await bot.setControlState('jump', false);
}

// Action implementations
async function attack(): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  const entity = bot.nearestEntity();
  if (entity) {
    await bot.lookAt(entity.position);
    await bot.attack(entity);
  } else {
    throw new Error('No target found to attack');
  }
}

async function use(): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  await bot.useOn(bot.blockAtCursor());
}

async function placeBlock(blockName: string): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  // Find the block in the bot's inventory
  const item = bot.inventory.items().find(item => {
    return item.name.toLowerCase().includes(blockName.toLowerCase());
  });
  
  if (!item) {
    throw new Error(`Block "${blockName}" not found in inventory`);
  }
  
  // Equip the block
  await bot.equip(item, 'hand');
  
  // Find the block the bot is looking at
  const referenceBlock = bot.blockAtCursor();
  if (!referenceBlock) {
    throw new Error('No block in sight to place against');
  }
  
  // Place the block
  await bot.placeBlock(referenceBlock, new Vec3(0, 1, 0));
}

async function equipItem(itemName: string): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  // Find the item in the bot's inventory
  const item = bot.inventory.items().find(item => {
    return item.name.toLowerCase().includes(itemName.toLowerCase());
  });
  
  if (!item) {
    throw new Error(`Item "${itemName}" not found in inventory`);
  }
  
  // Equip the item
  await bot.equip(item, 'hand');
}

// System implementations
async function sayMessage(message: string): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  bot.chat(message);
}

async function lookAt(x: number, y: number, z: number): Promise<void> {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  await bot.lookAt(new Vec3(x, y, z));
}

function listPlayers(): string {
  const bot = getBot();
  if (!bot) throw new Error('Bot not connected');
  
  const playerNames = Object.keys(bot.players);
  return `Players online (${playerNames.length}): ${playerNames.join(', ')}`;
}

// Help text
function getHelpText(): string {
  return `
Available commands:

Movement:
  move forward [blocks] - Move forward by specified blocks
  move backward [blocks] - Move backward by specified blocks
  turn left - Turn left by 90 degrees
  turn right - Turn right by 90 degrees
  jump - Make the bot jump once
  look [x] [y] [z] - Look at specified coordinates

Actions:
  attack - Attack the entity the bot is looking at
  use - Use the item the bot is holding
  place [block] - Place the specified block
  equip [item] - Equip the specified item

System:
  say [message] - Send a chat message
  list - List online players
  help - Show this help message
  `;
}
