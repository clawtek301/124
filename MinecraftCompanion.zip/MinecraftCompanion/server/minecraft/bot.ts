import mineflayer from 'mineflayer';
import { Vec3 } from 'vec3';
import { BotState } from '@shared/schema';
import { executeCommand } from './commandHandler';

let bot: mineflayer.Bot | null = null;
let botState: BotState = { connected: false };
let stateUpdateInterval: NodeJS.Timeout | null = null;

// Create a new bot instance
export async function createBot(options: {
  host: string;
  port: string;
  username: string;
  version: string;
  auth: string;
  email?: string;
  password?: string;
}): Promise<void> {
  // Disconnect existing bot if any
  if (bot) {
    await disconnectBot();
  }

  return new Promise((resolve, reject) => {
    try {
      // Initialize bot state
      botState = {
        connected: false,
        serverInfo: {
          host: options.host,
          port: options.port,
          version: options.version,
          username: options.username,
        }
      };

      // Configure mineflayer options
      const mineflayerOptions: mineflayer.BotOptions = {
        host: options.host,
        port: parseInt(options.port),
        username: options.username,
        version: options.version,
        auth: options.auth as 'microsoft' | 'mojang' | 'offline',
        hideErrors: false,
      };

      // Add credentials if auth is not offline
      if (options.auth !== 'offline') {
        if (!options.email || !options.password) {
          throw new Error('Email and password are required for Microsoft or Mojang authentication');
        }
        mineflayerOptions.password = options.password;
        if (options.auth === 'microsoft') {
          mineflayerOptions.authTitle = options.email;
        } else {
          mineflayerOptions.email = options.email;
        }
      }

      // Create the bot
      bot = mineflayer.createBot(mineflayerOptions);

      // Set up event handlers
      bot.once('spawn', () => {
        console.log('Bot spawned in the world');
        botState.connected = true;
        updateBotState();
        
        // Set up interval to update bot state periodically
        if (stateUpdateInterval) {
          clearInterval(stateUpdateInterval);
        }
        stateUpdateInterval = setInterval(updateBotState, 1000);
        
        resolve();
      });

      bot.on('error', (err) => {
        console.error('Bot error:', err);
        reject(err);
      });

      bot.on('end', (reason) => {
        console.log('Bot disconnected:', reason);
        botState.connected = false;
        
        if (stateUpdateInterval) {
          clearInterval(stateUpdateInterval);
          stateUpdateInterval = null;
        }
      });

      bot.on('health', () => {
        updateBotState();
      });

      bot.on('move', () => {
        updateBotState();
      });

      // Set a timeout in case the connection takes too long
      const timeout = setTimeout(() => {
        if (!botState.connected) {
          bot?.end();
          reject(new Error('Connection timed out'));
        }
      }, 30000);

      // Clear timeout when connected
      bot.once('spawn', () => {
        clearTimeout(timeout);
      });
    } catch (error) {
      console.error('Error creating bot:', error);
      reject(error);
    }
  });
}

// Disconnect the bot
export async function disconnectBot(): Promise<void> {
  if (bot) {
    try {
      await bot.end();
    } catch (error) {
      console.error('Error disconnecting bot:', error);
    } finally {
      bot = null;
      botState.connected = false;
      
      if (stateUpdateInterval) {
        clearInterval(stateUpdateInterval);
        stateUpdateInterval = null;
      }
    }
  }
}

// Update the bot state with current information
function updateBotState(): void {
  if (!bot) {
    botState.connected = false;
    return;
  }

  botState.connected = bot.entity !== undefined;
  
  if (botState.connected && bot.entity) {
    botState.position = {
      x: bot.entity.position.x,
      y: bot.entity.position.y,
      z: bot.entity.position.z,
    };
    
    botState.health = bot.health;
    botState.food = bot.food;
  }
}

// Get the current bot state
export function getBotState(): BotState {
  return botState;
}

// Get the bot instance
export function getBot(): mineflayer.Bot | null {
  return bot;
}

// Export executeCommand from commandHandler.ts
export { executeCommand };
