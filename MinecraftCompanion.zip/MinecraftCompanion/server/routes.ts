import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { connectionSchema, commandSchema, BotState } from "@shared/schema";
import { z } from "zod";
import { createBot, disconnectBot, getBotState, executeCommand } from "./minecraft/bot";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);

  // Create WebSocket server on a distinct path
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active connections
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    clients.add(ws);

    // Initial bot state
    sendToClient(ws, {
      type: 'botState',
      data: getBotState()
    });

    // Handle messages from clients
    ws.on('message', async (message) => {
      try {
        const msg = JSON.parse(message.toString());
        
        // Handle connect request
        if (msg.type === 'connect') {
          try {
            const validatedData = connectionSchema.parse(msg.data);
            const { serverAddress, serverPort, botUsername, mcVersion, authType, email, password } = validatedData;
            
            // Connect the bot
            await createBot({
              host: serverAddress,
              port: serverPort,
              username: botUsername,
              version: mcVersion,
              auth: authType,
              email,
              password
            });

            // Send success message
            sendToClient(ws, {
              type: 'log',
              text: `Connected to ${serverAddress}:${serverPort} as ${botUsername}`,
              logType: 'success'
            });

            // Broadcast updated bot state to all clients
            broadcastBotState();
          } catch (error) {
            if (error instanceof z.ZodError) {
              sendToClient(ws, {
                type: 'log',
                text: `Connection error: ${error.errors.map(e => e.message).join(', ')}`,
                logType: 'error'
              });
            } else {
              sendToClient(ws, {
                type: 'log',
                text: `Connection error: ${(error as Error).message || 'Unknown error'}`,
                logType: 'error'
              });
            }
          }
        }
        
        // Handle disconnect request
        else if (msg.type === 'disconnect') {
          disconnectBot();
          sendToClient(ws, {
            type: 'log',
            text: 'Disconnected from server',
            logType: 'system'
          });
          broadcastBotState();
        }
        
        // Handle command request
        else if (msg.type === 'command') {
          try {
            const validatedData = commandSchema.parse(msg.data);
            const response = await executeCommand(validatedData.command);
            
            sendToClient(ws, {
              type: 'log',
              text: response,
              logType: 'success'
            });
            
            // Bot state may have changed, update all clients
            broadcastBotState();
          } catch (error) {
            sendToClient(ws, {
              type: 'log',
              text: `Command error: ${(error as Error).message || 'Unknown error'}`,
              logType: 'error'
            });
          }
        }
      } catch (error) {
        console.error('Error handling message:', error);
        sendToClient(ws, {
          type: 'log',
          text: `Error: ${(error as Error).message || 'Invalid message format'}`,
          logType: 'error'
        });
      }
    });

    // Handle client disconnection
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      clients.delete(ws);
    });

    // Handle errors
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  // Function to broadcast bot state to all connected clients
  function broadcastBotState() {
    const botState = getBotState();
    const stateMessage = {
      type: 'botState',
      data: botState
    };
    
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(stateMessage));
      }
    });
  }

  // Function to send a message to a specific client
  function sendToClient(client: WebSocket, message: any) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(message));
    }
  }

  // Setup API routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  return httpServer;
}
