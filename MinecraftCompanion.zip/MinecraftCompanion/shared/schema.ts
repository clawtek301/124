import { pgTable, text, serial, integer, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Bot connection details
export const botConnections = pgTable("bot_connections", {
  id: serial("id").primaryKey(),
  serverAddress: text("server_address").notNull(),
  serverPort: text("server_port").notNull().default("25565"),
  botUsername: text("bot_username").notNull(),
  mcVersion: text("mc_version").notNull(),
  authType: text("auth_type").notNull(),
  userId: integer("user_id").references(() => users.id),
  active: boolean("active").default(false),
});

export const botConnectionSchema = createInsertSchema(botConnections).pick({
  serverAddress: true,
  serverPort: true,
  botUsername: true,
  mcVersion: true,
  authType: true,
});

// Bot auth details (optional)
export const botAuth = pgTable("bot_auth", {
  id: serial("id").primaryKey(),
  botConnectionId: integer("bot_connection_id").references(() => botConnections.id),
  email: text("email"),
  password: text("password"),
});

// Bot command log
export const commandLogs = pgTable("command_logs", {
  id: serial("id").primaryKey(),
  botConnectionId: integer("bot_connection_id").references(() => botConnections.id),
  command: text("command").notNull(),
  response: text("response"),
  timestamp: text("timestamp").notNull(),
});

// Define connection schema
export const connectionSchema = z.object({
  serverAddress: z.string().min(1, "Server address is required"),
  serverPort: z.string().default("25565"),
  botUsername: z.string().min(1, "Bot username is required"),
  mcVersion: z.string().default("1.19.3"),
  authType: z.enum(["microsoft", "mojang", "offline"]),
  email: z.string().email().optional(),
  password: z.string().optional(),
});

// Define command schema
export const commandSchema = z.object({
  command: z.string().min(1),
});

// Define bot state schema
export const botStateSchema = z.object({
  connected: z.boolean(),
  position: z.object({
    x: z.number(),
    y: z.number(),
    z: z.number(),
  }).optional(),
  health: z.number().optional(),
  food: z.number().optional(),
  inventory: z.array(z.any()).optional(),
  serverInfo: z.object({
    host: z.string(),
    port: z.string(),
    version: z.string(),
    username: z.string(),
  }).optional(),
});

// Types for our schemas
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type BotConnection = typeof botConnections.$inferSelect;
export type InsertBotConnection = z.infer<typeof botConnectionSchema>;
export type BotAuth = typeof botAuth.$inferSelect;
export type CommandLog = typeof commandLogs.$inferSelect;
export type ConnectionParams = z.infer<typeof connectionSchema>;
export type Command = z.infer<typeof commandSchema>;
export type BotState = z.infer<typeof botStateSchema>;
